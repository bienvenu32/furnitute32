  

 <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#"> <center><strong>Dashboard</strong></center></a>
            </li>
            <li class="breadcrumb-item active">Client</li>
          </ol> 
  
  <!-- carousel image slider -->

 <div class="container--head">
  <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
    
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
      <li data-target="#carousel-example-generic" data-slide-to="1"></li>
      <li data-target="#carousel-example-generic" data-slide-to="2"></li>
      <li data-target="#carousel-example-generic" data-slide-to="3"></li>
      <li data-target="#carousel-example-generic" data-slide-to="4"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="theme/carousel/client.jpg" alt="..." style="width:100%">
        <div class="carousel-caption">
          <h3></h3> 
        </div>
      </div>
      <div class="item">
        <img src="theme/carousel/buy.jpg" alt="..." style="width:100%">
        <div class="carousel-caption">
          <h3></h3>
        </div>
      </div>
      <div class="item">
        <img src="theme/carousel/client.jpg" alt="..." style="width:100%">
        <div class="carousel-caption">
          <h3></h3> 
        </div>
      </div>
      <div class="item">
        <img src="theme/carousel/client.jpg" alt="..." style="width:100%">
        <div class="carousel-caption">
          <h3></h3> 
        </div>
      </div>
     
     
    </div>

    <!-- Controls -->
    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
      <span class="fas fa-fw fa-chevron-left" style="padding: 250px 10px 10px 10px"></span>
    </a>
    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
      <span class="fas fa-fw fa-chevron-right" style="padding: 260px 10px 10px 10px"></span>
    </a>
  </div>
</div>

<!-- Fontawesome -->
<link href=css/font-awesome.min.css" rel="stylesheet">

<!-- Bootstrap -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<script src="js/indexes.js"></script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/1jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>
<br>
<br>





